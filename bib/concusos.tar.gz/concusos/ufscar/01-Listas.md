# 01 - Listas
Listas lineares: pilhas, filas, filas duplas; filas de prioridade; alocação sequencial e alocação ligada; listas circulares; listas duplamente ligadas; matrizes e listas ortogonais; skip lists OK01 

## Vocabulário em português e inglês e definições e relações entre vocábulos.
Passível de formalização como vocabulário SKOS (navegável por máquina e amistoso para interfaces computacionais para humanos).
- membros: listas lineares, pilhas, filas, filas duplas, filas de prioridade, alocação sequencial, alocação ligada, listas circulares, listas duplamente ligadas, matrizes, listas ortogonais, skip lists
- conceito de topo: estrutura de dados
- nota de escopo: vocabulário válido para ciência da computação
- nota: para organização da exposição, as implementações em pseudocódigo estão em seção separada.
- nota: organizações ontológicas em seção separada.
- nota: as estruturas de dados descritas neste vocabulário são canônicas
e implementadas na maioria das linguagens de programação.
- nota: o vocabulário pode ser expandido através de conceitos relacionados
encontrados ou não nas definições.

Nos conceitos que seguem, os termos preferenciais são os listados primeiro (exceto observação contrária)

### Conceito: estrutura de dados linear
- termos: estrutura de dados linear (pt), coleção sequencial (pt),
linear list (en), linear data structure (en), sequential collection (en)
- definição: uma estrutura de dados é dita linear se os dados formam uma sequência
- termos mais restritos: lista linear, vetor

### Conceito: lista linear
- termos: lista linear (ptbr), linear list (en) 

### Conceito: pilha
- termos: pilha (ptbr), stack (en), LIFO (en, ptbr), FILO (en, ptbr), stapelspeicher (de)
- nota de terminologia: os termos stack e heap são algumas vezes usados sem distinção.
Uma distinção usual é a de que uma stack possui uma quantidade fixa de memória
enquanto uma heap pode utilizar aloacação dinâmica de memória.
A distinção mais consistente é a de que são estruturas de dados diferentes.
Uma heap é uma árvore em que vértices pais são sistematicamente maiores que os filhos (max heap)
ou menores que os filhos (min heap).

- definição: um tipo de dados abstrato que serve
como uma coleção de elementos com duas operações principais:
  * empilhar (push), que adiciona um elemento à pilha (diz-se "no topo da pilha")
  * desempilhar (pop), que remove o último elemento adicionado (diz-se "do topo da pilha")
- nota: adicionalmente, uma operação de espiar (peek) pode permitir o acesso ao último
elemento sem removê-lo da pilha.
- nota: adicionalmente, pode ser implementada uma operação que retorna se a pilha está vazia ou não.
- nota: LIFO (Last In, First Out) é um termo utilizado tanto para designar pilhas
quanto para designar o mecanismo básico de funcionamento de pilhas:
o último a ser adicionado é o primeiro a ser removido.
Equivalente ao termo FILO (First In, Last Out).
- nota: a pilha pode ser implementada com capacidade limitada.
Caso a pilha não possua espaço suficiente ao receber um elemento
para ser empilhado, a pilha é então considerada em estado transbordante (overflow).
- nota: caso seja executada uma operação de desempilhar ou espiar e a pilha esteja vazia,
pode ocorrer subfluxo (underflow).
- nota: É comum que a operação de desempilhar consista não somente
em remover o elemento adicionado por último,
mas também no acesso ao valor do elemento.
- nota histórica: a pilha entrou na literatura científica com Alan Turing em 1946.
Havia já implementações anteriores (ao menos em 1945) e foi patenteada em 1957.
- representação pictórica: https://upload.wikimedia.org/wikipedia/commons/b/b4/Lifo_stack.png
- conceiro mais amplo: lista linear
- conceiro mais amplo: coleção sequencial
- pseudocódigos:
structure frame:
    data : item
    next : frame or nil

structure stack:
    head : frame or nil
    size : integer

procedure initialize(stk : stack):
    stk.head ← nil
    stk.size ← 0

procedure push(stk : stack, x : item):
    newhead ← new frame
    newhead.data ← x
    newhead.next ← stk.head
    stk.head ← newhead
    stk.size ← stk.size + 1

procedure pop(stk : stack):
    if stk.head = nil:
        report underflow error
    r ← stk.head.data
    stk.head ← stk.head.next
    stk.size ← stk.size - 1
    return r

- nota de implemetações: algumas linguagens, como Perl, LISP e Python,
disponibilizam as operações de empilhar e desempilhar em nas listas ou vetores padrão.

- nota de implementação: em Python e Javascript, as pilhas são em geral implementadas
a partir da lista (Python) ou vetor/array (JavaScript) padrão da linguagem ou utilizada a lista padrão diretamente.
Pode-se utilizar classes para os elementos e para a pilha de forma a obter uma implementação
mais fiel. (* desenvolver implementações se sobrar tempo *)
Em C/C++ as pilhas podem ser implementadas de forma mais restrita e eficiente
através do uso de ponteiros.
Neste caso, cada elemento possui tanto um valor quanto um ponteiro
para o próximo elemento e a pilha em si possui ao menos um ponteiro para o
elemento inserido por último.

- nota de aplicação: usos comuns de pilhas incluem:
  * Alocação e acesso a memória.
  Neste caso tipicamente a pilha se refere a uma região da memória com começo fixo e tamanho variável.
  Pode incluir operações de rotação nas quais o primeiro elemento é removido e inserido como primeiro ou vice-versa.
  * Várias famílias de CPU (e.g. x86) possuem registros dedicados (ou semi-dedicados/apropriados) para ponteiros de pilhas
  e possuem instruções especiais de empilhar e desempilhar para manipular estes registros.
  * Há diversas arquiteturas e microcontroladores que implementam pilhas em hardware por exemplo
  para evitar o uso de memória lenta.
  * Retroceder (backtracking), por exemplo no caso de percursos em um labirinto,
  em que, depois de encontrado um percurso que não resolve o problema.
  Outros casos são a busca por profundidade em grafos e a otimização por ramificação e limitação (Branch & Bound).
  deve-se utilizar os passos anteriores para retornar a algum ponto de bifurcação.
  A funcionalidade de Desfazer (undo) é muitas vezes implemetnada utilizando pilhas.
  * Linguagens livres de contexto podem ser analisadas (parsed) por algoritmos baseados em pilhas.
  * Muitos compiladores utilizam pilhas para analisar a sintaxe de expressões, 
  blocos de código, etc.
  * Muitas linguagens de programação são baseadas em pilhas no sentido em que
  operações básicas são realizadas desempilhando elementos de uma pilha
  e empilhando o resultado.
  * Muitas implementações eficientes de rotinas utilizam pilhas como a estrutura de dados básica
  (e.g. cadeia de vizinhos mais próximos, vizinhos menores).
  * Segurança: há ataques (e.g. stack smashing, buffer overflow)
  e vulnerabilidades em sistemas operacionais vinculadas às pilhas que implementam.
  Amenizar estas vulnerabilidades é uma área ativa de pesquisa.

### Conceito: fila
- termos: fila (ptbr), fila simples (ptbr), queue (en), simple queue (en), cola (es)
- definição: estrutura de dados abstrata que serve como uma coleção de elementos
e possui duas operaações básicas:
  * Inserção (enfileirar, enqueue): adição de elemento ao final da fila.
  * Remoção (desenfileirar, dequeue): remoção de elemento no começo da fila.
Ou seja, quando um elemento é adicionado, todos os elementos adicionados antes dele
devem ser removidos antes que ele seja removido.
- representação pictórica: https://en.wikipedia.org/wiki/Queue_(abstract_data_type)#/media/File:Data_Queue.svg
https://pt.wikipedia.org/wiki/FIFO#/media/File:Fifo_queue.png
- nota: FIFO (Fast In, First Out) é um termo utilizado tanto para designar filas
quanto para designar o mecanismo básico de funcionamento de filas:
o primeiro elemento a ser adicionado é o primeiro a ser removido.
- nota: adicionalmente, uma operação de espiar (peek ou front) pode permitir o acesso ao primeiro
elemento sem removê-lo.
- nota: É comum que a operação de remover consista não somente
em remover o elemento adicionado por último,
mas também no acesso ao valor do elemento.
- nota de implementação: em Python há uma implementação padrão de fila imbutida na linguagem.
Em Javascript, pode-se implementar filas com o array padrão da linguagem.
Em C++ a biblioteca padrão disponibiliza uma implementação de fila
em que são somente permitidas as operações de inserção e remoção.
- nota de implementação: implentações eficientes são aquelas em que
a inserção e a remoção de elementos são realizados em O(1).
- nota de implementação: teoricamente, as filas não possuem capacidade definida,
podendo sempre ser inserido um novo elemento.
- nota de aplicação: as filas são utilizadas como buffers em diversas aplicações
em que os elementos (e.g. pessoas, eventos ou processos) são registrados para processamento posterior.
Usos mais específicos e comuns de filas incluem:
  * Sistemas em que requisições, serviços, clientes são processados.
  * Buscas em grafos no paradigma "largura primeiro"
  * Em compiladores é comum utilizar filas para execução de instruções:
  as primeiras linhas são executadas primeiro.
  * Simulação e análise de sistemas reais que envolvem filas (e.g. filas de pessoas).
- pseudocódigos:
ENQUEUE (Q, x)
  Q[Q.tail] = x
  Q.tail += 1

DEQUEUE (Q)
  x = Q[Q.head]
  Q.head += 1
  return x

### Conceito: fila dupla
- termos: fila dupla (ptbr), fila de terminação dupla (ptbr),
double-ended queue (en), deque (en), double queue (en), head-tail linked list (en), dequeue (en)
- nota de termos: o termo dequeue é utilizado na literatura mas em geral considerado descontinuado (deprecated)
por também ser utilizado para designar a operação de remoção de elemento.
- conceito relacionado: fila
- definição: uma fila de terminação dupla (deque) é uma generalização
da fila em que elementos podem ser inseridos e removidos de ambos
o começo ou final da fila. Operações principais:
  * Inserção de elementos ao final (inject, snoc).
  * Inserção de elementos no começo (push, cons).
  * Remoção do último elemento (eject).
  * Remoção do primeiro elemento (pop).
Há a utilização dos termos "frente" e "trás" da fila, embora
haja inconsistências na literatura. Assim, explicitamos a convenção aqui utilizada:
  * Frente, começo da fila: consiste nos elementos inseridos antes.
  * Trás, final da fila: elementos inseridos mais recentemente.
- nota: pode-se implementar também operações de espiar (peek) elementos do início e final da fila.
- nota: pode-se implementar também operações para saber se a deque está cheia ou vazia.
- nota: deque de inserção/entreada restrita só permite inserção de elementos em uma das extremidades.
deque de remoção/saída restrita só permite remoção de elementos em uma das extremidades.
- nota de implementação: Implementações mais comuns incluem:
  * alocação dos elementos como uma lista circular, o que diminui a necessidade de redimensionar a deque.
  * alocação do conteúdo em um vetor a partir do centro.
  * alocação do conteúdo em vetores pequenos com indexação através de um vetor dinâmico.
- nota de implementação: A biblioteca padrão de C++ disponibiliza os modelos de classe
sd::deque e std::list com as implementações do deque através de múltiplos vetores
e de listas ligadas, respectivamente.
Python provê uma implementação de deque em seu módulo collections, padrão da linguagem.
Em JavaScript, as deques são em geral implementadas a partir do Array().
- nota: na implementação do deque como lista dupla,
a complexidade de acesso e escrita ao final, começo e no meio de um deque é O(1)
e para acesso randômico por índice é O(n).
Na implementação por vetor, a complexidade amortizada das operações básicas e do acesso
aleatório por índice é O(1)
e para inserção e remoção no meio é O(n).
- nota de aplicação: as deques são utilizadas quando há uma fila para processamento
e elementos podem ser removidos também do final (por exemplo, pessoas abandonam a fila).
As deques são também utilizadas muitas vezes como pilhas e filas.
Aplicações mais específicas de deque incluem:
  * Verificação de palíndromes
  * Agendamento de tarefas em processadores
  * Undo-Redo

### Conceito: fila de prioridade
- termos: fila de prioridade (ptbr), priority queue (en)
- definição: um tipo abstrato de dados em que cada elemento possui
uma associada uma prioridade que é respeitada na ordem de acesso
ou processamento.
Ou seja, os elementos com alta prioridade são servidos antes
dos de baixa prioridade.
As operações básicas são:
  * Inserir elemento X com prioridade Y
  * Inserir elemento X com máxima prioridade
- nota: é comum que a implementação incluia espiar/consultar (peek) elementos
com maior prioridade e a operação seja executada em tempo O(1).
- nota: implentações podem incluir operações mais elaboradas como inspeção
de elementos com prioridade alta ou baixa, remoção de todos os elementos ou algum conjunto,
mesclagem de filas de prioridade, etc.
- nota: pilhas e filas podem ser modeladas como tipos específicos de filas de prioridade
em que há respectivamente um acréscimo ou decréscimo constante da prioridade atribuída a cada elemento inserido.
- nota de implementação: as filas de prioridade são em geral implementadas como heaps
mas podem ser implementadas como conjuntos não ordenados ou outras estruturas de dados.
- nota de implementação: há implementações não otimizadas que são usadas
para ilustração do funcionamento e conceito de uma fila de prioridade.
Em geral a inserção é feita em O(1) e remoção em O(n)
(como no caso da implementação como um conjunto não ordenado
em que para a remoção é feita uma busca para encontrar a maior prioridade).
- nota de implementação: as implementações usuais envolvem uma heap
e resultam em O(logn) para inserção e remoção de elementos e O(nlogn)
para inicialização.
Variantes da heap (e.g. Fibonacci) podem implicar em resultados melhores para algumas operações.
- nota de implementação: Em C++, há diferentes implementações em uso corrente.
Em Python há o módulo heapq padrão da linguagem.
Em Javascript há implementações diversas disponilizadas por bibliotecas externas.
- pseudocódigo:
Encontra-Máximo (A, n)
   devolva  A[1]

Extrai-Máximo (A, n)
   max ← A[1]
   A[1] ← A[n]
   n ← n−1
   Corrige-Descendo (A, n, 1)
   devolva  max

Insere-na-Fila (A, n, c)
   A[n+1] ← c
   Corrige-Subindo (A, n+1)

Aumenta-Chave (A, i, c)
   A[i] ← c
   Corrige-Subindo (A, i)

Diminui-Chave (A, n, i, c)
   A[i] ← c
   Corrige-Descendo (A, n, i)

### Conceito: heap

### Conceito: alocação sequencial
- termos: alocação sequencial (ptbr), sequential allocation (en)
- definição: alocação de elementos em uma sequência prevista
e em localizações consecutivas na memória.
- nota: embora possa ser feito uso de alocação dinâmica de memória,
em geral a alocação sequencial envolve a alocação estática de memória
e, portanto, limitação na quantidade de elementos alocados
e desperdício de memória alocada para possível uso.
Em comparação com a alocação ligada,
há um custo computacional maior para inserção e remoção de elementos
em posições arbitrárias pois implica em realocação de elementos.
Em contrapartida, o acesso randômico aos elementos é mais barato.
- nota de aplicação: útil para processamento vetorial
e para casos em que o acesso aos elementos de forma randômica é recorrente.

### Conceito: alocação ligada
- termos: alocação ligada (ptbr), linked allocation (en)
- definição: organização de dados em que os elementos básicos
consistem de alguma estrutura de dados e uma referência para o outros elementos (e.g. próximo).
- nota: ver notas alocação sequencial.
- nota de aplicação: em geral envolve a alocação dinâmica de memória.
Há um custo menor para inserção e remoção de elementos
porém maior para acesso randômico aos elementos,
em comparação com a alocação sequencial.
- nota de implementação: as referências são em geral implementadas através de ponteiros,
mas podem também ser índices para elementos em um vetor ou deslocamentos no endereçamento da memória.

### Conceito: alocação indexada
- termos: alocação indexada (ptbr), indexed allocation (en)
- definição: como a alocação ligada, mas mantém também
uma relação dos ponteiros para cada elemento.
- nota: visa amenizar a dificuldade de acesso randômico aos elementos
no caso da lista ligada.

### Conceito: lista circular
- termos: lista circular, lista circularmente ligada, circular list, circularly linked list
- definição: lista ligada na qual o último elemento possui um ponteiro
para o primeiro elemento.
- nota: quando uma lista ligada não é circular ela é dita aberta ou linear.
- nota: no caso de uma lista circular duplamente ligada, o primeiro elemento possui
um ponteiro para o último elemento.
- nota de aplicação: usada para algumas implementações de fila e fila dupla.
Apropriada para funcionalidades que envolvam sequências recorrentes de elementos,
como músicas em um tocador, abas em um navegador web
ou turnos em algum jogo ou tarefa que envolva diversos agentes.
Exemplo disso é a alocação de processamento em um sistema operacional
para diversos usuários.


### Conceito: lista duplamente ligada
- termos: lista duplamente ligada, doubly linked list
- definição: estrutura de dados ligada em que os elementos
possuem duas referências: um para o elementos anterior e outro para o próximo.
- nota: é comum chamar os elementos de uma lista duplamente ligada
de nós. As referências entre os elementos são muitas vezes chamadas de ligações.
Os nós primeiro e útimos são também chamados de cabeça (head) e rabo (tail).
- representação pictórica: https://en.wikipedia.org/wiki/File:Doubly-linked-list.svg
- nota: ver alocação ligada.

### Conceito: sentinela
- termos: sentinela, nó sentinela, sentinel, sentinel node
- definição: elemento utilizado como finalizador de uma sequência ou percurso.
- nota: não contém ou referencia dados manipulados pela estrutura de dados.
- nota: utilizados muitas vezes ao invés de Null
para diminuir a complexidade de algoritmos e aumentar a velocidade de operações.

### Conceito: matriz
- termos: matriz, array
- definição: um conjunto de elementos indexados e passível ao menos
de duas operações:
  * Espiar (get) o valor do elemento com índice i.
  * Definir (set) o valor do elemento com índice i.
- nota: em geral, espera-se que uma matriz satisfaz os aximas:
  * get(set(A,I, V), I) = V
  * get(set(A,I, V), J) = get(A, J) if I ≠ J 
que implicam 1) que cada elemento é uma variável modificável;
2) elementos relacionados a índices diferentes são independentes.
Uma possível excessão à esta regra é o caso em que
dois elementos de uma matriz acessam a mesma instância de uma classe
ou o valor encontrado em um registro da memória,
caso no qual a alteração de um elemento interfere no valor do outro.
- nota: outras operações usuais em implementações de matrizes incluem
a obtenção do tamanho da matriz, fatiamento e operações de álgebra linear.
- nota: o número de índices necessários para acessar um elemento
em uma matriz é chamado de dimensão da matriz.
Em matrizes com dimensão maior que 1, em geral a implementação
é feita através de matrizes unidimensionais com referências
para outras matrizes unidimensionais.
- nota: muitas vezes o termo array é utilizado
para designar uma estrutura como definida acima
e com os elementos todos de mesmo tipo.
Outras vezes esta versão mais restrita do array
é chamado de vetor (vector).
- nota de implementação: é comum que implementações
restrinjam a indexação a números inteiros
e cada elemento como possuindo como valor um
mesmo tipo de dado e do mesmo tamamho.

### Conceito: lista ortogonal
- termos pt-br
- termos en
- definição
- nota de aplicação: úteis para implementação de matrizes esparsas.

### Conceito: skip list
- termos: skip list, skiplist
- definição: lista ligada em que é mantida uma hierarquia ligada
de sub-sequências.
- nota de aplicação: útil por permitir buscas rápidas em conjuntos ordenados.



## Descrição geral da teoria básica relacionada ao item
## Tipos de dados relacionados
- características abstratas (sequência ou conjunto de valores, dicionário, etc)
- proveniências (áudio, redes sociais, etc)
## Importância do item e limitações
## Demais notas teóricas
## Implementações em Pseudocódigo
## Ontologias
diagramas de conceitualização passível de formalização ontológica em OWL,
utilizável por máquina para realizar inferências, tomada de decisão e consulta aos dados
útil para discussões teoricas precisas
- Do item sorteado
- Do item sorteado com relação à ciência da computação
- Do item sorteado com relação a tipos de dados e visualizações
- Do item sorteado com relação a todos os itens propostos para o concurso
## Nota histórica
- origens
- percurso
- estado atual da teoria e implementações
## Problemas típicos e soluções canônicas
## Aplicações clássicas
## Exercícios interessantes
## Usos em aprendizado de máquina, classificação e otimização; Medições
## Visualizações de informação de dados relacionados ao item. Visualizações/diagramas/imagens pertinentes para a teoria do item.
## Usos artísticos e educacionais de representações audiovisuais do item; música
- encontrados na literatura e outros artefatos audiovisuais
- potenciais
## Software para implementação. Implementações em linguagens de programação (Python, Scheme, Javascript, Java, C/C++, Fortran, Bash, Vimscript, ChucK, SuperCollider, PD)
## Bibliografia
- Livros
- Artigos recentes que utilizam o item ou sobre desenvolvimentos no item.
