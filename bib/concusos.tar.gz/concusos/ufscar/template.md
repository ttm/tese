# Questões
- Utilizar JavaScript ou ES8?
- O que é amortized contant time?
- Arrays são traduzidos como vetores?
Qual a diferença entre array e vector?
- Ver com ric: se ok o argumento de SparQL e python não usar referências ou usarem por padrão arquivo aa/src/ontology.py

- O(n^1.00001) > O(nlogn) ??
- Qual a diferença entre NP-complete e NP-Hard?
- Greedy Algs pode ser considerado um caso especial de Dynamic Programming?
- Prevejo relacionar estruturas de dados (e operações básicas),
algoritmos de análise e métodos de visualização.
Como abordar também engenharia de software?
- Diferenças entre matrizes, arrays e listas ortogonais?
- Implementação de estruturas de dados em disco? Tem no livro do Ziviani um pouco.
- Revisão de complexidade de algoritmos O o Theta outros.
- Um sort, ou média e std ou regex são mais rápidos no endpoint sparql
ou no Python?
Decidir até que ponto as operações podem ser feitas no endpoint. Fatores:
  * processamento no SparQL é confiável até onde?
  * Quanto mais dado é enviado para o python,
  mais utiliza-se o trafego na rede.
  Então a geração de estruturas derivadas
  em conjunto com a original não é tão interessante.
  * processamento do SparQL pode ser utilizado para minimar o trafego
  se não for utilizada a estrutura original.

No Sparql:
  * Obtenção de redes junto a metadados de vértices e arestas.
  * Ordenação.
  * Obtenção de dq:Slice ou dados em segundo algum critério (e.g. âmbito).
  * Descrição estatítica geral: média, max, min, n de palavras, etc.
  * Escrever os dados gerados para consulta posterior. (todos?)
  * ??

No Python:
  * Realização de histogramas, curve fitting, PCA/MDS
  * Manutenção e registro de estado dos dados, análises, visualizações e interface (usuário, sessão, etc) no endpoint sparql.
  * Cálculo de quantís e medidas estatísticas mais elaboradas que a descrição baixada do SparQL (e.g. kurtosis).
  * Síntese de queries SparQL e arquivos RDF:
    - Para relacionamentos entre dados, análises, audiovisuaizações e interfaces (DAAI)
    - Para inferências de relações possíveis em DAAI.
  * 
  
No JavaScript:
  * layout de redes.

Como prevenir que o usuário faça queries que sobrecarreguem os servidores
com leitura e escrita? (remoção é na interface por padrão)



# 01 - Listas
Listas lineares: pilhas, filas, filas duplas; filas de prioridade; alocação sequencial e alocação ligada; listas circulares; listas duplamente ligadas; matrizes e listas ortogonais; skip lists OK01 

## Vocabulário em português e inglês e definições e relações entre vocábulos.
Passível de formalização como vocabulário SKOS (navegável por máquina e amistoso para interfaces computacionais para humanos).
- membros
- conceito de topo
- nota de escopo: vocabulário válido para ciência da computação
- nota: para organização da exposição, as implementações em pseudocódigo estão em seção separada.
- nota: organizações ontológicas em seção separada.
- nota: fontes: 
  * http://dbpedia.org/page/Stack_(abstract_data_type)
  * wikipedia ptbr e en
  * livros
  * artigos

Nos conceitos que seguem, os termos preferenciais são os listados primeiro (exceto observação contrária)

### (CONCEITO)
- termos pt-br
- termos en
- definição
- exemplo (de uso em uma sentença creio)
- nota
- nota: uso
- nota de escopo
- broader
- narrower
- related
- diferente de
- notação

### (CONCEITO)
- termos pt-br
- termos en
- definição

## Descrição geral da teoria básica relacionada ao item
## Tipos de dados relacionados
- características abstratas (sequência ou conjunto de valores, dicionário, etc)
- proveniências (áudio, redes sociais, etc)
## Importância do item e limitações
## Demais notas teóricas
## Implementações em Pseudocódigo
## Ontologias
diagramas de conceitualização passível de formalização ontológica em OWL,
utilizável por máquina para realizar inferências, tomada de decisão e consulta aos dados
útil para discussões teoricas precisas
- Do item sorteado
- Do item sorteado com relação à ciência da computação
- Do item sorteado com relação a tipos de dados e visualizações
- Do item sorteado com relação a todos os itens propostos para o concurso
## Nota histórica
- origens
- percurso
- estado atual da teoria e implementações
## Problemas típicos e soluções canônicas
## Aplicações clássicas
## Exercícios interessantes
## Usos em aprendizado de máquina, classificação e otimização; Medições
## Visualizações de informação de dados relacionados ao item. Visualizações/diagramas/imagens pertinentes para a teoria do item.
## Usos artísticos e educacionais de representações audiovisuais do item; música
- encontrados na literatura e outros artefatos audiovisuais
- potenciais
## Software para implementação. Implementações em linguagens de programação (Python, Scheme, Javascript, Java, C/C++, Fortran, Bash, Vimscript, ChucK, SuperCollider, PD)
## Bibliografia
- Livros
- Artigos recentes que utilizam o item ou sobre desenvolvimentos no item.
