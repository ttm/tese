Ver slides ric de conjuntos independentes.
20 min mems
20 min arvores
20 min slides dos moocs
10 min O o Omega etc


Citar o topcoder para exercitar.
As visualizações como no site da ufscar para ilustrar,
assim como videos no youtube.

Relacionar os tópicos com Google Cloud, Firebase e App Engine;
com Algorithmia; com endpoints SparQL;
com as visualizações online de operações básicas em estruturas de dados da UFSCar;
com analítica visual, métodos de análise de dados (e interfaces?);

Fazer um disclaimer ao final da prova:
De *** para frente o conteúdo desta prova relaciona
a bibliografia que consta no edital do concurso (Cormen, Dasgupta, Ziviani).
Reconheço, portanto, que a seção possa ser considerada fora do escopo.
Mesmo assim, tive que escolher o que dava tempo de escrever para vocês,
e acho que o que consta nestes livros já temos de comum repertório.
Espero ter entregado ao menos um escrito interessante.
Peço que seja considerado ao máximo o esforço e disponho-me a
colaborar com o DC para, por exemplo, documentar as visualizações online
das estruturas de dados com pseudocódigos disponibilizados pela UFSCar,
implementações ilustrativas (e.g. SparQL e RDF, Python, C/C++)
e direções para as implementações em utilização (e.g. na stdlib).

Ver notas historicas do Dasgupta antes da prova. Decorar.

Tentar adequar um template para a prova segundo o edital.



Fazer do visual analytics vocabulary and ontology
até as estruturas de dados propostas no trabalho,
com exemplos de pseudocódigo e implementações em C/C++
e Python (tudo quanto possível).

Exemplificar com uma extensão das estruturas
ontológicas (incluindo vocabulário e código)
para o item que cair no dia da prova.
Usar python mesmo quando proveitoso
(lista ligada):

class Node:
    def __init__(self, cargo=None, next=None):
        self. car = cargo
	self.next = next
    def __str__(self):
        return str(self.car)
        
def display(list):
    if list:
        print(list)
	display(list)
    else:
       print("nil")

Para dados em lista, são apropriados
métodos de visualização de séries temporais e sequenciais em geral.
Já para pilhas, a visualização tende a ser:

Contemplar também as visualizações em:
https://www.cs.usfca.edu/~galles/visualization/Algorithms.html
Outras fontes?

Linked lists:
o fundamento é manter um ponteiro/referência/registro para
cada elemento seguinte e para o primeiro elemento da lista ligada.

  
Possibilidades imediatas:
sonificar as visualizações geradas

Relacionar com as estruturas sociais pelo tipo de dado gerado
e as visualizações geradas.
Relacionar os tipos de dados aos utilizados em SparQL e RDF em geral.
Relacionar com a obtenção de dados de um certo tipo
(rede de interações a partir de emails
e medidas topológicas, textuais.
Calcular/estimar ou ao menos apontar os potenciais ganhos
em performance para uma utilização,
para uma sequência de utilizações,
para um grupo de pesquisa,
para institutos e para a sociedade com acesso à Web.
Justificar a discussão da escala pelo artigo
do Chu no arXiv.


(Grace et all) "When Will AI Exceed Human Performance?
Evidence from AI Experts"

Contemplar o uso de conjuntos e não listas,
mas notar que manter um conjunto de medidas em ordem
pode facilitar o relacionamento de cada dado/medida
a elementos de outro conjunto de dados/medidas.
Como pesar isso em implementações de escalas diferentes
e para tarefas diferentes?

Sobre audiovisual analytics,
o áudio tem uma potência muito grande através da música.
A percepção de altura e volume varia bastante
ao ponto que intervalos de notas musicais,
como segunda maior (2M) ou sexta menor (6m),
não serem perceptíveis a vários músicos,
incluíndo John Cage (Schoenberg parou de dar aulas
para ele depois que constatou que ele não tinha
percepção de melodia, como frases, pergunta e resposta e temas)
e diz-se até do Ravel (não conferi na literatura, mas o folclore
é de que não reconhecia intervalos de altura mesmo).
Ou seja, há um apelo por mapeamentos que façam uso
de estruturas mais gerais, como fraseados rítmicos,
paisagens sonoras, cadências harmônicas e linguagem natural
(fala sintetizada ou gravada).

Por isso, o termo analítica audiovisual.

Usar decorator no python para que os códigos
possam estar vinculados à ontologia facilmente.
Como fazer no Javascript?

Há real ganho no uso destas estruturas de dados
em Python? Em JavaScript?
Isso motiva a escrita em C/C++?
E em Fortran?

As implementações em Python e outras linguagens não utilizam pointer.
Pode-se dizer também que usam pointers por padrão.

int a = 1;
int *b = *a;
a = 2
count << *b << endl; # 2

python:
a = 1
b = a
b = 2
print(b) # 2







*) Vocabulário em português e inglês e definições e relações entre vocábulos.
Passível de formalização como vocabulário SKOS.

(CONCEITO)
termos pt-br
termos en
definição

(CONCEITO)
termos pt-br
termos en
definição

*) Descrição geral da teoria básica relacionada ao item
*) Tipos de dados relacionados
+ características abstratas (sequência ou conjunto de valores, dicionário, etc)
+ proveniências (áudio, redes sociais, etc)
*) Importância do item e limitações
*) Demais notas teóricas
*) Implementações em Pseudocódigo
*) Ontologias:
(diagramas de conceitualização passível de formalização ontológica em OWL,
utilizável por máquina para realizar inferências, tomada de decisão e consulta aos dados
útil para discussões teoricas precisas)
+ Do item sorteado
+ Do item sorteado com relação à ciência da computação
+ Do item sorteado com relação a técnicas de análise, tipos de dados e visualizações
+ Do item sorteado com relação a todos os itens propostos para o concurso
*) Nota histórica
+ origens
+ percurso
+ estado atual da teoria e implementações
*) Problemas típicos e soluções canônicas
*) Aplicações clássicas
*) Exercícios interessantes
*) Usos em aprendizado de máquina, classificação e otimização; Medições
*) Visualizações de informação de dados relacionados ao item. Visualizações/diagramas/imagens pertinentes para a teoria do item.
*) Usos artísticos e educacionais de representações audiovisuais do item; música
+ encontrados na literatura e outros artefatos audiovisuais
+ potenciais
*) Software para implementação. Implementações em linguagens de programação (Python, Scheme, Javascript, Java, C/C++, Fortran, Bash, Vimscript, ChucK, SuperCollider, PD)
*) Bibliografia
+ Livros
+ Artigos recentes que utilizam o item ou sobre desenvolvimentos no item.

========
*) projeto pedagógico para o plano de trabalho http://bcc2.dc.ufscar.br/ e http://enc.dc.ufscar.br/
*) O que é comprovação no "itens efetivamente comprovados no corriculum vitae documentado"
*) Deve-se procurar alguma junta médica oficial para emissão de laudo? 15.1.5. ter aptidão física e mental, para o exercício das atribuições do cargo, comprovada por junta médica oficial.
*) 

*) Marcar visita ao departamento
*) Fazer implementações em Bash, Python, Vimscript, Javascript, C++


Lista de Temas da Prova escrita e Prova didática:
1. Listas lineares: pilhas, filas, filas duplas; *filas de prioridade*; alocação sequencial e alocação ligada; listas circulares; listas duplamente ligadas; matrizes e listas ortogonais; skip lists OK01 
(faltam filas duplas, listas circulares, matrizes e listas ortogonais e skip lists)
2. Árvores: terminologia, representação; algoritmos de manipulação e percursos em árvores binárias. Árvores de busca binária; árvores de busca AVL; árvores rubro-negras de busca; árvore de busca ótima; B-árvores. OK
3. Tabelas de espalhamento (hash tables) OK1
4. Implementação de estruturas de dados em disco ?
5. Grafos: representações, busca em largura, busca em profundidade e suas aplicações OK
6. Algoritmos de ordenação em memória primária e em memória secundária e suas complexidades OK01 (como abordar memória pimária e secundária?)
8. Técnicas de projetos de algoritmos: programação dinâmica e backtracking OK1
9. Técnicas de projetos de algoritmos: divisão e conquista e algoritmos gulosos OK1
10. Técnicas de projetos de algoritmos: Problemas NP-Completos OK

7. Problema do caminho mínimo em grafos e suas variações: principais algoritmos e suas complexidades OK
 djstra


Bibliografia Recomendada
CORMEN, T. H.; LEISERSON, C.E.; RIVEST, R.L.; Algoritmos: Teoria e Prática. Editora Campus, Tradução da 2ª edição americana, 2002.
Cormen, Thomas H., Charles E. Leiserson, Ronald L. Rivest, and Clifford Stein.Introduction to algorithms. Vol. 2. Cambridge: MIT press, 2001.
Dasgupta, Sanjoy, Christos H. Papadimitriou, and Umesh Vazirani. Algorithms. McGraw-Hill, Inc., 2006.
ZIVIANI, N.; Projeto de Algoritmos com implementação em Java e C++. Editora Thomson, 1ª edição, 2006.

MOOCs:
*) https://www.coursera.org/specializations/data-structures-algorithms
*) https://www.coursera.org/specializations/algorithms
*) https://www.coursera.org/learn/algorithms-part1
*) https://www.coursera.org/learn/algorithms-part2
*) https://www.coursera.org/learn/analysis-of-algorithms
*) https://www.youtube.com/playlist?list=PLUl4u3cNGP61Oq3tWYp6V_F-5jb5L2iHb
