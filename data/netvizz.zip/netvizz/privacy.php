<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
	<title>index.php</title>
	
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	
	<link href="facebook.css" rel="stylesheet" type="text/css" />
	
</head>

<body class="fbbody">

<h1>netvizz privacy policy</h1>

Hello. My name is <a href="http://rieder.polsys.net">Bernhard Rieder</a>, I am an Assistant Professor in Media Studies at the University of Amsterdam and I wrote this app as a reasearch tool for myself
and thought that it might be useful to other people as well. I do not store any of your profile information other than the graph files themselves and those are removed from the server at regular intervals.
The for questions contact <a href="mailto:rieder@uva.nl">rieder@uva.nl</a>.<br /><br />
Facebook is a complicated thing and the app regularly breaks for some users in some contexts. Before reporting a problem, please read <a href="http://www.chiark.greenend.org.uk/~sgtatham/bugs.html">this</a>.

</body>
</html>