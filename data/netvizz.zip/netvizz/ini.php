<?php

// +++++ database connection data +++++

$hostname =	"localhost";				// define hostname
$database =	"facebook"; 					// define database name
$dbuser =	"root"; 					// user
$dbpass =	"";

$hostname =	"localhost";				// define hostname
$database =	"facebook"; 				// define database name
$dbuser =	"root"; 					// user
$dbpass =	"4qnarfekx1";

$appid = '107036545989762';
$secret = '0dba97f06b3db97ae45b7d6b5f716d1d';

// +++++ database connection functions +++++

function dbconnect() {
	global $hostname,$database,$dbuser,$dbpass,$db;
	$db = mysql_connect($hostname,$dbuser,$dbpass) or die("Database error");
	mysql_select_db($database, $db);
	mysql_set_charset('utf8',$db);
}

function dbclose() {
	global $db;
	mysql_close($db);
}

?>