<?php

// create a .gdf from personal network or group
// http://apps.facebook.com/netvizz/

// written by Bernhard Rieder (rieder@uva.nl)
// use freely for research purposes

require './src/facebook.php';
require './ini.php';

ignore_user_abort(false);
set_time_limit(3600*10);
ini_set("memory_limit","1024M");
ini_set("error_reporting","0");

$facebook = new Facebook(array(
  'appId'  => $appid,	
  'secret' => $secret
));

$user_id = $facebook->getUser();

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
	<title>netvizz</title>
	
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	
	<link href="facebook.css" rel="stylesheet" type="text/css" />
	
	<script type="text/javascript" language="javascript">

	function sendForm(_action) {

		document.getElementById("user_action").value = _action;
		document.getElementById("user_dataform").submit();
	}
	
	function sendPage(_id) {
		
		_num = document.getElementById("page_posts").value;
		
		window.open("index.php?action=pages&pageid="+_id+"&posts="+_num);
		
	}
	
	</script>
	
</head>

<body class="fbbody">

<h1>netvizz v0.6</h1>

<?php

if (isset($_SERVER["REMOTE_ADDR"]))    {
	$clientip = $_SERVER["REMOTE_ADDR"];
} else if (isset($_SERVER["HTTP_X_FORWARDED_FOR"]))    {
	$clientip = $_SERVER["HTTP_X_FORWARDED_FOR"];
} else if (isset($_SERVER["HTTP_CLIENT_IP"]))    {
	$clientip = $_SERVER["HTTP_CLIENT_IP"];
}

$nowdate = date("Y_m_d_H_i");

// declarative identity rank : about_me, activities, books, interests, movies, music, political, profile_blurb, quotes, religion, tv  

if(!$user_id ) {
	$url = $facebook->getLoginUrl(array('scope' => 'user_status,user_groups,user_interests,friends_interests,friends_likes,user_likes,user_about_me,friends_about_me'));
	echo "<script type=\"text/javascript\">parent.location.href = '$url';</script>";
	exit;
}  

if(!isset($_GET["action"])) {

	echo '<p>
	This application allows you to create <a href="http://guess.wikispot.org/The_GUESS_.gdf_format" target="_blank">gdf files</a> (a simple
	text format that specifies an undirected graph) from the friendship relations of either your personal network or the groups
	you are a member of. These files can then be analyzed and visualized using graph visualization software such as 
	<a href="http://graphexploration.cond.org/" target="_blank">GUESS</a> or the powerful and very easy to use <a href="http://gephi.org/" target="_blank">gephi</a>
	platform. Big networks may take some time to process. <b>Be patient!</b>
	</p>
	
	<p>Privacy policy and credits are <a href="https://lab.digitalmethods.net/~brieder/facebook/netvizz/privacy.php">here</a>.</p>
	
	<hr class="fbcontentdivider" />
	
	<h2>your personal network:</h2>
	
	<form method="get" action="index.php" id="user_dataform" target="_blank">
		<b>Step 1</b> - Select user data to include in the file:<br /><br />
		<input id="user_action" type="hidden" name="action">
		<input id="user_sex" type="checkbox" name="sex" /> sex
		<input id="user_wallcount" type="checkbox" name="wallcount" /> wall posts count
		<input id="user_locale" type="checkbox" name="locale" /> interface language<br />
		Derived measures & ranks :<br />
		<input id="user_agerank" type="checkbox" name="agerank" /> profile age rank (oldest profile = highest value) <br />
		<input id="user_declarative" type="checkbox" name="declarative" /> declarative intensity (length of text in fields like activities, books, etc.)
	</form>
	
	<p><b>Step 2</b> - create a gdf file from your personal network using the:<br /><br />
	- fast but sloppy algorithm by clicking <a href="javascript:sendForm(\'personal\')">here</a> (for small friend networks, can fail with big ones)<br />
	- slow but robust algorithm by clicking <a href="javascript:sendForm(\'huge\')">here</a> (for big networks, may take several minutes)
	</p>
	
	<hr class="fbcontentdivider" />
	
	<h2>your like network:</h2>

	Create a bipartite network (gdf file) from your friends and their likes (both users and liked objects are nodes) <a href="javascript:sendForm(\'like\')">here</a>. Only liked pages are provided, not external objects. Count on waiting about a second per friend.
	</p>
	
	<hr class="fbcontentdivider" />
	
	<h2>groups:</h2>
	
	<p>You are a member of the following groups. By clicking on one of the group names, a gdf file will be generated. The API limits for group data are changing regularly,
	the current version should be able to get up to 5000 group members. This may take a very long time (hours).</p>
	
	<p>';
	
		$permissions = $facebook->api('/me/permissions'); 
		
		//print_r($permissions);
		
		if($permissions["data"][0]['user_groups'] == 1) {
		
			$groups = $facebook->api('/me/groups');
			
			//print_r($groups);
			
			foreach($groups["data"] as $group) {
				echo '<a href="index.php?action=group&groupid='.$group["id"].'"  target="_blank">'.$group["name"].'</a><br />';
			}
	
		} else {
			
			echo "This application cannot access your group listing because it does not have the necessary permission.";
			
			$url = $facebook->getLoginUrl(array('scope' => 'user_status,user_groups'));
			echo "<script type=\"text/javascript\">parent.location.href = '$url';</script>";
			exit;
		}
	
	echo '</p>
	
	<hr class="fbcontentdivider" />
	
	<h2>pages:</h2>
	
	<p>You have "liked" the following pages. The script gets the last posts (specify number in the field below) on the page and creates a) a bipartite graph file in gdf format that shows posts, users, and connections between the two. A user is connected to a post of she commented or liked it, and b) a stat file (tsv) that lists different metrics for each post. May take a couple of minutes.</p>
	
	<input id="page_posts" type="text" value="50" maxlength="3" size="3" /> latest posts (max. 999)
	
	<p>';
	
	
		
		if($permissions["data"][0]['user_likes'] == 1) {
		
			$pages = $facebook->api('/me/likes');
			
			//print_r($groups);
			
			foreach($pages["data"] as $page) {
				echo '<a href="javascript:sendPage(\''.$page["id"].'\')">'.$page["name"].'</a><br />';
			}
	
		} else {
			
			echo "This application cannot access your like listing because it does not have the necessary permission.";
			
			$url = $facebook->getLoginUrl(array('scope' => 'user_status,user_groups'));
			echo "<script type=\"text/javascript\">parent.location.href = '$url';</script>";
			exit;
		}
	
	echo '</p><hr class="fbcontentdivider" />';
	echo '<p>0.6 - 23.10.2012 - Added page data feature (<a href="http://thepoliticsofsystems.net/2012/10/new-netvizz-feature-page-networks-and-statistics/">blog post</a>)';
	echo '<p>0.51 - 09.09.2012 - Cosmetic changes';
	echo '<p>0.5 - 08.09.2012 - Added like network feature (<a href="http://thepoliticsofsystems.net/2012/09/new-netvizz-feature-bipartite-like-networks/">blog post</a>)</p>';
	echo '<p>0.44 - 25.05.2012 - Major bug fixed, huge and groups should be much faster now</p>';
	echo '<p>0.43 - 23.05.2012 - Finally moved to new server, https works now</p>';
	echo '<p>0.42 - 30.01.2012 - Group methods updated</p>';
	echo '<p>0.41 - 11.10.2011 - Fixed group permissions</p>';
	echo '<p>0.4 - 29.9.2011 - Moved everything to the graph API</p>';
	
	echo '<p>IP: '.$clientip.'</p>';
	
	$_GET["action"] = "";
}




// ------------------------------------------
// getting personal network
// ------------------------------------------

if($_GET["action"] == "personal") {
	
	$friends = array();
	$friendnames = array();
	$areFriends = array();
	$datatoget = array('name');
	if($_GET["sex"] == "on") { $datatoget[] = "sex"; }
	if($_GET["wallcount"] == "on") { $datatoget[] = "wall_count"; }
	if($_GET["locale"] == "on") { $datatoget[] = "locale"; }	
	if($_GET["declarative"] == "on") { $datatoget = array_merge($datatoget,array("about_me", "activities", "books", "interests", "movies", "music", "political", "profile_blurb", "quotes", "religion", "tv")); }	
	
	
	// -------------------------------------------------------------------------
	// query and data preparation
	
	$query = $facebook->api(array(       
		'method' => 'fql.multiquery',       
		'queries' => '{ 
			"friends":"SELECT uid2 FROM friend WHERE uid1='.$user_id.'",
			"mutualfriends":"SELECT uid1,uid2 FROM friend WHERE uid1 IN (SELECT uid2 FROM #friends) and uid2 IN (SELECT uid2 from #friends)" 
		}',       
		'callback' => ''
	));
		
	$areFriends = $query[1]["fql_result_set"];
	
	
	for($i = 0; $i < count($query[0]["fql_result_set"]);$i++) {
		$friends[] = $query[0]["fql_result_set"][$i]["uid2"];
	}
	
	$friendnames = array();
	
	for($i = 0; $i < count($friends); $i = $i + 200) {
		
		$tmp = $facebook->api(array(
			'method' => 'facebook.users.getInfo',
			'uids' => join(",",array_slice($friends,$i,200)),
			'fields' => $datatoget
		));
		
		$friendnames = array_merge($friendnames,$tmp);
	}
	
	$friends = null;
	
	
	// -------------------------------------------------------------------------
	// clean up double mentions of friends
	
	$tmpArray = array();
	
	$speed = count($areFriends);
	for($i = 0; $i < $speed; $i++) {
		if(!in_array(array("uid1"=>$areFriends[$i]["uid2"],"uid2"=>$areFriends[$i]["uid1"]),$tmpArray)) {
			$tmpArray[] = $areFriends[$i];
		}
	}
	
	$areFriends = $tmpArray;
	$tmpArray = null;
	
	
	// -------------------------------------------------------------------------
	// output
	
	$filename = './data/' . $user_id."_".$nowdate."_".md5($nowdate).".gdf";
	$content = "";
	
	$content .= "nodedef>name VARCHAR,label VARCHAR";
	if($_GET["sex"] == "on") { $content .= ',sex VARCHAR'; }
	if($_GET["agerank"] == "on") { $content .= ',agerank INT'; }
	if($_GET["wallcount"] == "on") { $content .= ',wallcount INT'; }
	if($_GET["locale"] == "on") { $content .= ',locale VARCHAR'; }
	if($_GET["declarative"] == "on") { $content .= ',declarative_intensity INT'; }
	$content .= "\n";
	
	for($i = 0; $i < count($friendnames); $i++) {
		
		$content .= $friendnames[$i]["uid"] . "," . $friendnames[$i]["name"];
		//. "," . (count($friendnames) - $i) . "," . $friendnames[$i]["wall_count"]
		if($_GET["sex"] == "on") { $content .= ','.$friendnames[$i]["sex"]; }
		if($_GET["agerank"] == "on") { $content .= ','.(count($friendnames) - $i); }
		if($_GET["wallcount"] == "on") { $content .= ','.$friendnames[$i]["wall_count"]; }
		if($_GET["locale"] == "on") { $content .= ','.$friendnames[$i]["locale"]; }
		if($_GET["declarative"] == "on") {
			$tmp = $friendnames[$i]["about_me"]. $friendnames[$i]["activities"]. $friendnames[$i]["books"]. $friendnames[$i]["interests"]. $friendnames[$i]["movies"]. $friendnames[$i]["music"]. $friendnames[$i]["political"]. $friendnames[$i]["profile_blurb"]. $friendnames[$i]["quotes"]. $friendnames[$i]["religion"]. $friendnames[$i]["tv"];
			$content .= ','.strlen($tmp);
		}
		
		$content .= "\n";
	}
	
	$content .= "edgedef>node1 VARCHAR,node2 VARCHAR\n";
	
	for($i = 0; $i < count($areFriends); $i++) {
		$content .= $areFriends[$i]["uid1"] . "," . $areFriends[$i]["uid2"] . "\n";
	}
	
	file_put_contents($filename, $content);
	
	
	logit($filename,$clientip,count($friendnames));
	
	// -------------------------------------------------------------------------
	// html
	
	echo '<h2>download</h2>';
	
	echo '<p>'.count($friendnames).' nodes, '.count($areFriends).' edges</p>';
	
	echo '<p>Your <a href="'.$filename.'">gdf file</a> (right click, save as...).</p>';
}




// ------------------------------------------
// getting huge network
// ------------------------------------------

if($_GET["action"] == "huge") {
	
	$selfarray = array();
	$otherarray = array();
	$datatoget = array('name');
	if($_GET["sex"] == "on") { $datatoget[] = "sex"; }
	if($_GET["wallcount"] == "on") { $datatoget[] = "wall_count"; }
	if($_GET["locale"] == "on") { $datatoget[] = "locale"; }	
	if($_GET["declarative"] == "on") { $datatoget = array_merge($datatoget,array("about_me", "activities", "books", "interests", "movies", "music", "political", "profile_blurb", "quotes", "religion", "tv")); }	
	
	
	// -------------------------------------------------------------------------
	// check graph edges
	
	$friendlist = $facebook ->api('/me/friends');
	
	$friends = array();
	
	foreach($friendlist["data"] as $friend) {
	
		$friends[] = $friend["id"];
	}
	
	
	$friendnames = array();
	
	for($i = 0; $i < count($friends); $i = $i + 200) {
		//$tmp = $fb->api_client->users_getInfo(join(",",array_slice($friends,$i,200)), $datatoget);
		$tmp = $facebook->api(array(
			'method' => 'facebook.users.getInfo',
			'uids' => join(",",array_slice($friends,$i,200)),
			'fields' => $datatoget
		));
		$friendnames = array_merge($friendnames,$tmp);
	}
	
	
	for($i = 0; $i < count($friendnames); $i++) {
		
		for($j = $i; $j < count($friendnames); $j++) {
		
			if($i != $j) {
				$selfarray[] = $friendnames[$i]["uid"];
				$otherarray[] = $friendnames[$j]["uid"];
			}
		}
	}
	
	
	// -------------------------------------------------------------------------
	// generate output
	
	$filename = "./data/huge_".$user_id."_".$nowdate."_".md5($nowdate).".gdf";
	$content = "";
	$edgecounter = 0;
	
	$content .= "nodedef>name VARCHAR,label VARCHAR";
	if($_GET["sex"] == "on") { $content .= ',sex VARCHAR'; }
	if($_GET["agerank"] == "on") { $content .= ',agerank INT'; }
	if($_GET["wallcount"] == "on") { $content .= ',wallcount INT'; }
	if($_GET["locale"] == "on") { $content .= ',locale VARCHAR'; }
	if($_GET["declarative"] == "on") { $content .= ',declarative_intensity INT'; }
	$content .= "\n";
	
	for($i = 0; $i < count($friends); $i++) {
		$content .= $friendnames[$i]["uid"] . "," . $friendnames[$i]["name"];
		//. "," . (count($friendnames) - $i) . "," . $friendnames[$i]["wall_count"]
		if($_GET["sex"] == "on") { $content .= ','.$friendnames[$i]["sex"]; }
		if($_GET["agerank"] == "on") { $content .= ','.(count($friendnames) - $i); }
		if($_GET["wallcount"] == "on") { $content .= ','.$friendnames[$i]["wall_count"]; }
		if($_GET["locale"] == "on") { $content .= ','.$friendnames[$i]["locale"]; }
		if($_GET["declarative"] == "on") {
			$tmp = $friendnames[$i]["about_me"]. $friendnames[$i]["activities"]. $friendnames[$i]["books"]. $friendnames[$i]["interests"]. $friendnames[$i]["movies"]. $friendnames[$i]["music"]. $friendnames[$i]["political"]. $friendnames[$i]["profile_blurb"]. $friendnames[$i]["quotes"]. $friendnames[$i]["religion"]. $friendnames[$i]["tv"];
			$content .= ','.strlen($tmp);
		}
		
		$content .= "\n";
	}
	
	$content .= "edgedef>node1 VARCHAR,node2 VARCHAR\n";
	
	file_put_contents($filename, $content);
	
	
	$content = "";
	
	$blocksize = 30;
	$u1pos = 0;
	$u2pos = 0;
	
	asort($friends);
	$numFriends = count($friends);
	
	//if($numFriends > 3000) {
	//	$blocksize = 40;
	//}
	
	$queries1 = array();
	$queries2 = array();
	foreach($friends as $friend) {
		$queries1[] = "uid1=" . $friend;
		$queries2[] = "uid2=" . $friend;
	}
	
	$pairs = array();
	

	for($u1pos = 0; $u1pos < $numFriends; $u1pos = $u1pos + $blocksize) {

		echo $u1pos . " of " . $numFriends . "<br />";
				
		for ($u2pos = $u1pos; $u2pos < $numFriends; $u2pos = $u2pos + $blocksize) {
			
			$u1query = join(" OR ",array_slice($queries1, $u1pos, $blocksize));
			$u2query = join(" OR ",array_slice($queries2, $u2pos, $blocksize));
			
			$query = "SELECT uid1, uid2 FROM friend WHERE (".$u1query.") AND (".$u2query.")";
			
			$areFriends = $facebook->api(array(       
				'method' => 'fql.query',       
				'query' => $query,       
				'callback' => ''
			));
			
			flush();
			ob_flush();
			
			usleep(500000);
			
			if($areFriends != "") {

				for($k = 0; $k < count($areFriends); $k++) {
					$string1 = $areFriends[$k]["uid1"] . "," . $areFriends[$k]["uid2"] . "\n";
					$string2 = $areFriends[$k]["uid2"] . "," . $areFriends[$k]["uid1"] . "\n";
					if(!isset($pairs[$string1]) && !isset($pairs[$string2])) {
						$content .= $string1;
						$pairs[$string1] = true;
						$edgecounter++;
						}
				}
				
				file_put_contents($filename, $content,FILE_APPEND);
				
				$content = "";
				
			} else {
				
				$u2pos = $u2pos - $blocksize;
				
				usleep(1000000);
			}
		}
	}


	logit($filename,$clientip,count($friendnames));

	// -------------------------------------------------------------------------
	// html
	
	echo '<h2>download</h2>';
	
	echo '<p>'.count($friendnames).' nodes, '.$edgecounter.' edges</p>';
	
	echo '<p>Your <a href="'.$filename.'">gdf file</a> (right click, save as...).</p>';
}




// ------------------------------------------
// getting like network
// ------------------------------------------

if($_GET["action"] == "like") {
	
	$selfarray = array();
	$otherarray = array();
	$datatoget = array('name','sex','wall_count','locale');
	
	// -------------------------------------------------------------------------
	// get friends' basic info
	
	$friendlist = $facebook ->api('/me/friends');
	
	$friends = array();
	
	foreach($friendlist["data"] as $friend) {
	
		$friends[] = $friend["id"];
	}
	
	
	$friendnames = array();
	
	for($i = 0; $i < count($friends); $i = $i + 200) {
		//$tmp = $fb->api_client->users_getInfo(join(",",array_slice($friends,$i,200)), $datatoget);
		$tmp = $facebook->api(array(
			'method' => 'facebook.users.getInfo',
			'uids' => join(",",array_slice($friends,$i,200)),
			'fields' => $datatoget
		));
		$friendnames = array_merge($friendnames,$tmp);
	}
	
	$likes = array();
	
	echo "<br />friends processed: ";
	
	// -------------------------------------------------------------------------
	// get friends' likes
	
	for($i = 0; $i < count($friends); $i = $i + 1) {
		$tmps = $facebook->api('/'.$friends[$i].'/likes');
		foreach($tmps["data"] as $tmp) {
			if(!isset($likes[$tmp["id"]])) {
				$likes[$tmp["id"]] = array();
				$likes[$tmp["id"]]["name"] = $tmp["name"];
				$likes[$tmp["id"]]["category"] = $tmp["category"];
				$likes[$tmp["id"]]["count"] = 1;
				$likes[$tmp["id"]]["likedby"] = array($friends[$i]);
			} else {
				$likes[$tmp["id"]]["count"]++;
				$likes[$tmp["id"]]["likedby"][] = $friends[$i];
			}
		}
		
		echo $i . " ";
		
		flush();
		ob_flush();
		
		usleep(500000);
	}
	
	// -------------------------------------------------------------------------
	// generate output
	
	$filename = "./data/like_".$user_id."_".$nowdate."_".md5($nowdate).".gdf";
	$content = "";
	$edgecounter = 0;
	
	$content .= "nodedef>name VARCHAR,label VARCHAR,type VARCHAR,likesize INT,sex VARCHAR,wallcount INT,locale VARCHAR\n";
	
	for($i = 0; $i < count($friends); $i++) {
		$content .= $friendnames[$i]["uid"] . "," . $friendnames[$i]["name"] . ",person,1";
		//$content .= $friendnames[$i]["uid"] . ",username,person,1";
		//. "," . (count($friendnames) - $i) . "," . $friendnames[$i]["wall_count"]
		$content .= ','.$friendnames[$i]["sex"];
		$content .= ','.$friendnames[$i]["wall_count"];
		$content .= ','.$friendnames[$i]["locale"];
		$content .= "\n";
	}
	
	foreach ($likes as $key => $value) {
		
		$key = preg_replace("/[,\"\']/","_",$key);
		$key = preg_replace("/[\n\r\t]/","_",$key);
	
		$content .= $key . "," . preg_replace("/[,\"]/","_",$value["name"])  . ",like," . $value["count"];
		$content .= "\n";
	}
	

	
	$content .= "edgedef>node1 VARCHAR,node2 VARCHAR\n";
	
	foreach($likes as $key => $value) {
		foreach($value["likedby"] as $likedby) {
			$content .= $key . "," . $likedby . "\n";
			$edgecounter++;
		}
	}
	
	file_put_contents($filename, $content);

	logit($filename,$clientip,count($friendnames));

	// -------------------------------------------------------------------------
	// html
	
	echo '<h2>download</h2>';
	
	echo '<p>'.count($friendnames).' users, ' . count($likes) . ' different liked objects, ' .$edgecounter.' likes</p>';
	
	echo '<p>Your <a href="'.$filename.'">gdf file</a> (right click, save as...).</p>';
}



// ------------------------------------------
// getting group info
// ------------------------------------------

if($_GET["action"] == "group" && isset($_GET["groupid"])) {

	$selfarray = array();
	$otherarray = array();
	
	
	// -------------------------------------------------------------------------
	// check graph edges
	
	$gid = $_GET["groupid"];
	$gmembers = array();
	
	$exit = 0;
	$count = 0;
	
	while($exit == 0) {
		
		$oldcount = count($gmembers);
		
		$newgmembers = $facebook->api(array(       
			'method' => 'fql.query',       
			'query' => 'SELECT uid FROM group_member WHERE gid='.$gid.' LIMIT ' . $count * 500 . ',500',       
			'callback' => ''
		));
		
		for($i = 0; $i < count($newgmembers); $i++) {
			if(!in_array($newgmembers[$i]["uid"],$gmembers)) {
				array_push($gmembers,$newgmembers[$i]["uid"]);
			}
		}
		
		if(count($gmembers) == $oldcount) {
			$exit = 1;
		}
		
		if($count == 9) {
			$exit = 1;
		}
		
		$count++;
		
		echo $count . " ";
		flush();
		ob_flush();
	}
	
	echo "<br /><br />";
	
	
	// -------------------------------------------------------------------------
	// generate output
	
	$membernames = array();
	
	for($i=0; $i < count($gmembers); $i = $i + 100) {
		
		 $tmp = $facebook->api(array(
			'method' => 'facebook.users.getInfo',
			'uids' => join(",",array_slice($gmembers,$i,100)),
			'fields' => array('name','locale','sex')
		));
		
		$membernames = array_merge($membernames,$tmp);
	}
	
	//print_r($membernames);
	
	$filename = "./data/group_".$gid."_".$nowdate."_".md5($nowdate).".gdf";
	$content = "";
	$edgecounter = 0;
	
	$content .= "nodedef>name VARCHAR,label VARCHAR,sex VARCHAR,locale VARCHAR\n";
	
	for($i = 0; $i < count($membernames); $i++) {
		$content .= $membernames[$i]["uid"] . "," . $membernames[$i]["name"] . "," . $membernames[$i]["sex"] . "," . $membernames[$i]["locale"] . "\n";
	}
	
	$content .= "edgedef>node1 VARCHAR,node2 VARCHAR\n";
	
	file_put_contents($filename, $content);
	$content = "";
	
	
	$blocksize = 30;
	$u1pos = 0;
	$u2pos = 0;
	
	asort($gmembers);
	$numFriends = count($gmembers);
	
	//if($numFriends > 3000) {
	//	$blocksize = 40;
	//}
	
	$queries1 = array();
	$queries2 = array();
	foreach($gmembers as $gmember) {
		$queries1[] = "uid1=" . $gmember;
		$queries2[] = "uid2=" . $gmember;
	}
	
	$pairs = array();
	

	for($u1pos = 0; $u1pos < $numFriends; $u1pos = $u1pos + $blocksize) {

		echo $u1pos . " of " . $numFriends . "<br />";
				
		for ($u2pos = $u1pos; $u2pos < $numFriends; $u2pos = $u2pos + $blocksize) {
			
			$u1query = join(" OR ",array_slice($queries1, $u1pos, $blocksize));
			$u2query = join(" OR ",array_slice($queries2, $u2pos, $blocksize));
			
			$query = "SELECT uid1, uid2 FROM friend WHERE (".$u1query.") AND (".$u2query.")";
			
			//	echo $query;
			
			$areFriends = null;
			
			$areFriends = $facebook->api(array(       
				'method' => 'fql.query',       
				'query' => $query,       
				'callback' => ''
			));
			
			flush();
			ob_flush();
			
			usleep(500000);
			
			if($areFriends != "") {
				
				for($k = 0; $k < count($areFriends); $k++) {
					$string1 = $areFriends[$k]["uid1"] . "," . $areFriends[$k]["uid2"] . "\n";
					$string2 = $areFriends[$k]["uid2"] . "," . $areFriends[$k]["uid1"] . "\n";
					if(!isset($pairs[$string1]) && !isset($pairs[$string2])) {
						$content .= $string1;
						$pairs[$string1] = true;
						$edgecounter++;
					}
				}
				
				file_put_contents($filename, $content,FILE_APPEND);
				
				$content = "";
				
			} else {
				
				$u2pos = $u2pos - $blocksize;
				
				usleep(1000000);				
			}
		}
	}
		
	logit($filename,$clientip,count($membernames));

	// -------------------------------------------------------------------------
	// html
	
	echo '<h2>download</h2>';
	
	echo '<p>'.count($membernames).' nodes, '.$edgecounter.' edges</p>';
	
	echo '<p>Your <a href="'.$filename.'">gdf file</a> (right click, save as...).</p>';
}


// ------------------------------------------
// getting page info
// ------------------------------------------

if($_GET["action"] == "pages" && isset($_GET["pageid"])  && isset($_GET["posts"])) {

	if($_GET["override"] != "true" && (preg_match("/[^0-9]/",$_GET["posts"]) || $_GET["posts"] > 999)) {
		echo "check pages parameter";
		exit;
	}
	
	$toget = $_GET["posts"];
	$frame = 10;
	$until = false;

	$pids = array();
	$pids[] = $_GET["pageid"];
	
	//$pids = array(8304333127,5281959998);
	// nytimes: 8304333127
	// WSJ: 5281959998
	
	$nodes = array();
	$edges = array();
	
	foreach($pids as $pid) {
	
		$posts = array();
		$postsnl = array();
		
		$i = 0;
		while($i < $toget) {
			
			$query = '/'.$pid.'/posts?fields=message,likes.limit(1000),comments.limit(1000).fields(like_count,from)&limit=' . $frame;
			if($until != false) { $query .= "&until=" . $until; }
			
			$tmp = $facebook->api($query);
			$posts = array_merge($posts,$tmp["data"]);
			
			if(count($tmp["data"]) == 0) {
				break;
			}
			
			usleep(500000);
			
			$query = '/'.$pid.'/posts?fields=type,message,likes,comments,shares&limit=' . $frame;
			if($until != false) { $query .= "&until=" . $until; }
			
			$tmp = explode("&until=", $tmp["paging"]["next"]);
			$until = $tmp[1];
			
			$tmp = $facebook->api($query);
			$postsnl = array_merge($postsnl,$tmp["data"]);
			
			usleep(500000);
			
			$i += $frame;
			
			echo "pid: " . $pid . " " . $i . " of " . $toget . "<br>";
			
			flush();
			ob_flush();
		}

		
		$pcount = count($posts);
		
		if($pcount == 0) {
			echo "No public posts on this page.";
			exit;
		}
		
		//echo $pcount;
		
		//print_r($posts);
		//print_r($postsnl);
		//exit;
		
		$i = 0;
		$tsv = "type\tpost_message\tpost_published\tpost_published_alt\tfulllikes\tfullcomments\tshares\tcomment_likes\tengagement\n";
		
		foreach($posts as $post) {
		
			$msg = preg_replace("/[,\"\']/","_",$post["message"]);
			$msg = preg_replace("/[\n\r\t]/","_",$msg);
			
			
			$type = $postsnl[$i]["type"];
			$fulllikes = ($postsnl[$i]["likes"]["count"] == "") ? 0:$postsnl[$i]["likes"]["count"];
			$fullcomments = ($postsnl[$i]["comments"]["count"] == "") ? 0:$postsnl[$i]["comments"]["count"];
			$shares = ($postsnl[$i]["shares"]["count"] == "") ? 0:$postsnl[$i]["shares"]["count"];
			
		
			$nodes[$post["id"]] = array(
				"type" => "post_".$pid,		// used to be "post"
				"type_post" => $type,	
				"label" => $msg,
				"fulllikes" => $fulllikes,
				"fullcomments" => $fullcomments,
				"shares" => $shares,
				"comment_likes" => 0,
				"engagement" => 0
			);
		
			foreach($post["likes"]["data"] as $like) {
				if(!isset($nodes[$like["id"]])) {
					$nodes[$like["id"]] = array(
						"type" => "user",
						"type_post" => "user",
						"label" => preg_replace("/[,\"\']/","_",$like["name"]),
						"fulllikes" => 1,
						"fullcomments" => 0,
						"engagement" => 1
					);
				} else {
					$nodes[$like["id"]]["engagement"]++;
					$nodes[$like["id"]]["fulllikes"]++;
				}
				
				if(!isset($edges[$post["id"]."_XXX_".$like["id"]])) {
					$edges[$post["id"]."_XXX_".$like["id"]] = 1;
				} else {
					$edges[$post["id"]."_XXX_".$like["id"]]++;
				}
			}
			
			foreach($post["comments"]["data"] as $comment) {
				if(!isset($nodes[$comment["from"]["id"]])) {
					$nodes[$comment["from"]["id"]] = array(
						"type" => "user",
						"type_post" => "user",
						"label" => preg_replace("/[,\"\']/","_",$comment["from"]["name"]),
						"fulllikes" => 0,
						"fullcomments" => 1,
						"engagement" => 1
					);
				} else {
					$nodes[$comment["from"]["id"]]["engagement"]++;
					$nodes[$comment["from"]["id"]]["fullcomments"]++;
				}
				
				$nodes[$post["id"]]["comment_likes"] += $comment["like_count"];
				
				
				if(!isset($edges[$post["id"]."_XXX_".$comment["from"]["id"]])) {
					$edges[$post["id"]."_XXX_".$comment["from"]["id"]] = 1;
				} else {
					$edges[$post["id"]."_XXX_".$comment["from"]["id"]]++;
				}
			}
		
			$engagement = $fullcomments + $fulllikes + $shares + $nodes[$post["id"]]["comment_likes"];
			
			$nodes[$post["id"]]["engagement"] = $engagement;
			
			$tsv .= $type . "\t" .$msg . "\t" . $postsnl[$i]["created_time"] . "\t" . date('Y-m-d H:i:s', strtotime($postsnl[$i]["created_time"])) . "\t" . $fulllikes . "\t" . $fullcomments . "\t" . $shares . "\t" . $nodes[$post["id"]]["comment_likes"] . "\t" . $engagement . "\n";
		
			$i++;
		}
	}
	
	//print_r($nodes);
	//print_r($edges);
	
	// -------------------------------------------------------------------------
	// generate output
	
	$edgecounter = 0;
	$nodecounter = 0;
	
	$fn = "./data/page_".$pid."_".$nowdate."_".md5($nowdate);
	$filename = $fn . ".gdf";
	$filename_tsv = $fn . ".tsv";
	$content = "";
	
	$content .= "nodedef>name VARCHAR,label VARCHAR,type VARCHAR,type_post VARCHAR,engagement INT,fulllikes INT,fullcomments INT\n";
	
	foreach($nodes as $key => $node) {
		$content .= $key . "," . $node["label"] . "," . $node["type"] . "," . $node["type_post"] . "," . $node["engagement"] . "," . $node["fulllikes"] . "," . $node["fullcomments"] . "\n";
		$nodecounter++;
	}
	
	$content .= "edgedef>node1 VARCHAR,node2 VARCHAR,weight INT\n";
	
	foreach($edges as $key => $edge) {
		$tmp = explode("_XXX_", $key);
		$content .= $tmp[0] . "," . $tmp[1] . "," . $edge . "\n";
		$edgecounter += $edge;
	}
	
	file_put_contents($filename, $content);
	file_put_contents($filename_tsv, $tsv);

	logit($filename,$clientip,count($friendnames));

	// -------------------------------------------------------------------------
	// html
	
	echo '<h2>download</h2>';
	
	echo '<p>extracted data from ' . $pcount . ' posts, with ' . ($nodecounter - $pcount) . ' users liking or commenting ' . $edgecounter . ' times</p>';
	
	echo '<p>Your <a href="'.$filename.'">gdf file</a> (right click, save as...).</p>';
	echo '<p>Your <a href="'.$filename_tsv.'">tsv file</a> (right click, save as...).</p>';

}


function logit($filename,$clientip,$size) {
	$logtext = date('Y-m-d H:i:s') . " " . $size . " " . $clientip . " " . $filename . "\n";
	file_put_contents("access.log", $logtext,FILE_APPEND);
}

?>

</body>
</html>